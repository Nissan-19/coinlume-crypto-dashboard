import { formatCurrency } from "../utils/formatCurrency"
import { useSelector } from "react-redux"

const MARKET_COLORS = [
  "#3b82f6",
  "#8b5cf6",
  "#14b8a6",
  "#f59e0b",
  "#22c55e",
]

function TopMarketCapShare({topCoins, apiStatus}) {
  //we are saying use the received coins array. if no coin prop was provided, use an empty array
  // other wise the slice will not work and crash

  const selectedCurrency = useSelector((state) => state.currency.selectedCurrency)
  const currencyRates = useSelector((state) => state.currency.rates)

  const totalTopFiveMarketCap = topCoins.reduce((total, coin) => {
    return total + Number(coin.market_cap_usd || 0)//It protects against a missing or empty value i.e. it did not return anything or empty use 0
   //without ||0 if the api returns anything else than a no, our Number becomes undefined NaN. this is a defence mechanism
  }, 0)
   //reduce turns several value in to a final value which is the combined market cap
  // total is the amount calculated so far and coin is current coin being processed
  //0 is the starting value
  //coinlore often give market-cap values as string so we need to convert into number for prper calculayion


  const marketShareData = topCoins.map((coin, index) => {
    // the api returns too much unnecassary data. we use map to tranform
    //each api coin into simple object for ui with only the values we need for the graph
    const marketCap = Number(coin.market_cap_usd || 0)
    //This converts the current coin’s market cap into a number.
    const percentage =
      totalTopFiveMarketCap > 0
        ? (marketCap / totalTopFiveMarketCap) * 100
        : 0 //this 0 is prtection against divinging by 0 ie when data is not not loaded it becomes 0/0
            // because when data is not loaded marketcap is 0
    return {
      id: coin.id,
      name: coin.name,
      percentage,
      color: MARKET_COLORS[index],
    }
  })

  return (
    <section className="overflow-hidden rounded-xl mt-4 mb-4 border border-slate-200 bg-white shadow-lg dark:border-slate-800 dark:bg-slate-900">
      <div className="flex flex-col gap-3 border-b border-slate-200 px-6 py-5 sm:flex-row sm:items-center sm:justify-between dark:border-slate-800">
        <div>
          <h2 className="text-xl font-semibold text-slate-900 dark:text-white">
            Top 5 Market Cap Share
          </h2>

          <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
            Distribution among the five largest cryptocurrencies
          </p>
        </div>

        <div className="sm:text-right">
          <p className="text-xs uppercase tracking-wide text-slate-500 dark:text-slate-400">
            Combined market cap
          </p>

          <p className="mt-1 text-xl font-semibold text-slate-900 dark:text-white">

            {formatCurrency(
                          totalTopFiveMarketCap,
                          selectedCurrency,
                          currencyRates,
                          true,
                        )}
          </p>
        </div>
      </div>

      {apiStatus === "idle" || apiStatus === "loading" ? (
        <p className="px-6 py-10 text-center text-slate-500 dark:text-slate-400">
          Loading market data...
        </p>
      ): apiStatus === "failed"?(
        <p className="px-6 py-10 text-center text-red-600 dark:text-red-400">
          Failed to load market data
        </p>

      ) : (
        <div className="px-6 py-6">
          <div className="flex h-6 overflow-hidden rounded-full bg-slate-200 dark:bg-slate-800">
            {marketShareData.map((coin) => (
              <div
                key={coin.id}
                title={`${coin.name}: ${coin.percentage.toFixed(1)}%`}  //format the no to 1 Digit after decimal 
                className="h-full transition-all duration-500"
                style={{
                  width: `${coin.percentage}%`,
                  backgroundColor: coin.color,
                }}
              />
            ))}
          </div>

          <div className="mt-6 overflow-x-auto">
  <div className="grid min-w-150 grid-cols-5 gap-3">
    {marketShareData.map((coin, index) => (
      <article
        key={coin.id}
        className="rounded-lg border border-slate-200 p-4 dark:border-slate-800"
      >
        <div className="flex items-center justify-between gap-3">
          <div
            className="flex h-8 w-8 items-center justify-center rounded-full text-sm font-semibold text-white"
            style={{
              backgroundColor: coin.color,
            }}
          >
            {index + 1}
          </div>

          <span className="text-lg font-semibold text-slate-900 dark:text-white">
            {coin.percentage.toFixed(1)}%
          </span>
        </div>

        <p className="mt-4 font-semibold text-slate-900 dark:text-white">
          {coin.name}
        </p>
      </article>
    ))}
  </div>
</div>
        </div>
      )}
    </section>
  )
}

export default TopMarketCapShare